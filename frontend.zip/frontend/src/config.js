
export const BASE_URL = 'http://127.0.0.1:8000'
export const REGISTER = 'http://127.0.0.1:8000/register'
export const LOGIN = 'http://127.0.0.1:8000/login'
export const SETTINGS = 'hhttp://127.0.0.1:8000/settings'
export const DASHBOARD = 'http://127.0.0.1:8000/dashboard'
export const ROUTE = 'http://127.0.0.1:8000/generate-route'
