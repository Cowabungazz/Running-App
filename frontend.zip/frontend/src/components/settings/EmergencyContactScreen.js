import { View, Text } from "react-native"

const EmergencyContactScreen = () =>{
    return (
        <View>
            <Text>hi</Text>
        </View>
    )
}

export default EmergencyContactScreen