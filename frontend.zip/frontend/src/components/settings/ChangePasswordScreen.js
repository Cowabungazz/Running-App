import { View, Text, StyleSheet, SafeAreaView, TextInput, TouchableOpacity } from "react-native"
import { SETTINGS } from "../../config";
import axios from "axios";
import { useState } from "react";

const ChangePasswordScreen = () =>{
    const [newPassword, setNewPassword] = useState('');

    const changePassword = async (newPassword) => {
        await axios.put(`${SETTINGS}/${userInfo.username}/change-password?new_password=${newPassword}`, {
            headers: {
                'Authorization': `Bearer ${userToken}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(() => {})
    };

    return (
        <SafeAreaView>
            <View style={styles.textInput}>
                <TextInput
                    placeholder="New Password"
                    onChangeText={(text) => setNewPassword(text)}
                    autoCapitalize={"none"}
                    style={styles.field}
                />
            </View>
            <TouchableOpacity onPress={()=>{changePassword(newPassword)}}>
                <Text>Save Password</Text>
            </TouchableOpacity>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({

})

export default ChangePasswordScreen