import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ProfileScreen from '../home/ProfileScreen';
import EditProfileScreen from './EditProfileScreen';
import ChangePasswordScreen from './ChangePasswordScreen';
import EmergencyContactScreen from './EmergencyContactScreen';
import TermsAndConditionsScreen from '../login/TermsAndConditionsScreen'

const Stack = createNativeStackNavigator();

const SettingsStack = () => {
    
    return (
        <Stack.Navigator>
            <Stack.Screen name="Settings" options={{headerShown: false}} component={ProfileScreen} />
            <Stack.Screen name="Edit" options={{headerShown: false}} component={EditProfileScreen} />
            <Stack.Screen name="Change" options={{headerShown: false}} component={ChangePasswordScreen} />
            <Stack.Screen name="Emergency" options={{headerShown: false}} component={EmergencyContactScreen} />
            <Stack.Screen name="Terms" options={{headerShown: false}} component={TermsAndConditionsScreen} />
        </Stack.Navigator>
    )
}

export default SettingsStack;
