import { View, Text, SafeAreaView, TouchableOpacity, TextInput, StyleSheet, Image } from "react-native"
import { Ionicons } from "@expo/vector-icons"; 
import { useContext, useState } from "react";
import axios from "axios";
import { AuthContext } from "../../context/AuthContext";

const EditProfileScreen = () =>{
    const {userToken} = useContext(AuthContext)

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [location, setLocation] = useState('');
    const [contact, setContact] = useState('');

    const getDetails = async() =>{
        // try{
        //     const res = await axios.get(`${/**/}/${/**/}`, {
        //         headers: {Authorization: `Bearer ${userToken}`}
        //     })
        //     const details = res.data
        //     setFirstName(details.firstName);
        //     setLastName(details.LastName);
        //     setLocation(details.location);
        //     setContact(details.contact);
        // } catch(error) {
        //     console.error(error);
        // }   
    }

    const saveDetails = async(firstName, lastName, location, contact) =>{

    }

    return (
        <SafeAreaView style={styles.container}>
            <Text style={styles.header}>Edit Your Profile</Text>
            <View style={styles.form}>
                <Text style={styles.purpleUnderline}>
                    First Name
                </Text>
                <View style={styles.textInput}>
                    <TextInput
                        placeholder="First Name"
                        onChangeText={(text) => setFirstName(text)}
                        autoCapitalize={"none"}
                        style={styles.field}
                    />
                </View>

                <Text style={styles.purpleUnderline}>
                    Last Name
                </Text>
                <View style={styles.textInput}>
                    <TextInput 
                        placeholder="Last Name" 
                        onChangeText={(text) => setLastName(text)}
                        autoCapitalize={"none"}
                        style={styles.field}
                    />
                </View>

                <Text style={styles.purpleUnderline}>
                    Location
                </Text>
                <View style={styles.textInput}>
                    <TextInput 
                        placeholder="Locaton" 
                        onChangeText={(text) => setLocation(text)}
                        autoCapitalize={"none"}
                        style={styles.field}
                    />
                </View>

                <Text style={styles.purpleUnderline}>
                    Contact Number
                </Text>
                <View style={styles.textInput}>
                    <TextInput 
                        placeholder="Contact Number" 
                        onChangeText={(text) => setContact(text)}
                        autoCapitalize={"none"}
                        style={styles.field}
                    />
                </View>

                <TouchableOpacity 
                    style={styles.button}
                    onPress={()=>saveDetails()}
                >
                    <Text style={styles.text}>SAVE</Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
      },
      form:{
        flexDirection: 'column',
        justifyContent: 'center',
      },
      header:{
        textAlign: 'center',
        fontWeight: '600',
        fontSize: 24
      },
      text: {
          color: 'grey',
          fontSize: 16,
          textAlign: 'center',
          marginTop: 5,
          marginBottom: 5,
      },
      textInput: {
          backgroundColor: '#f8f8ff',
          borderColor: '#e6e6fa',
          borderWidth: 1,
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 15,
          margin: 10,
          borderRadius: 10,
          shadowColor: 'black',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.15,
          shadowRadius: 1.84,
          elevation: 5,
          marginTop: 5,
          marginLeft: 35,
          marginRight: 35,
          marginBottom:18,
      },
      field: {
          flex: 1,
      },
      purpleText: {
          color: '#9360E3',
          fontWeight: 'bold',
      },
      purpleUnderline:{
          color: '#9360E3',
          fontWeight: 'bold',
          fontSize: 14,
          marginLeft: 40,
          textDecorationLine: 'underline',
          marginTop: 6,
      },
      button:{
        backgroundColor: '#9360E3',
        width: 100,
        borderRadius: 30
      }
});

export default EditProfileScreen