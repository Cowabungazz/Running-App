import { View, Text } from "react-native"

const EventsScreen = () =>{
    return (
        <View>
            <Text>Events</Text>
        </View>
    )
}

export default EventsScreen