import React from 'react';
import MapView, {Polyline, Marker} from 'react-native-maps';
import { StyleSheet, TextInput,TouchableOpacity, Pressable, View, Button, Text, Image, Dimensions, Touchable } from 'react-native';
import {useState} from 'react';
import ReactDOM from 'react-dom';
import { useEffect } from 'react';
import axios from "axios";
import { ROUTE } from "../../config";
import { AuthContext } from '../../context/AuthContext';
import  TimerApp from "./timerApp";
import * as Location from "expo-location";

const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

export default function RoutesScreen() {

    const {userToken} = React.useContext(AuthContext);
    //console.log(userToken);

    const locationNTU = {
      latitude: 1.3483,
      longitude: 103.6831,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    };

    const [startingPoint, setStartingPoint] = React.useState({"latitude": 1.3485971625954045, "longitude": 103.68233638828144});
    const [endPoint, setEndPoint] = React.useState({"latitude": 1.3497177506157445, "longitude": 103.68497425931214});
    const [distance, setDistance] = React.useState('');
    const [decodedRoutes, setDecodedRoutes] = useState([{"latitude": 1.3485971625954045, "longitude": 103.68233638828144}]);
    const [currentLocation, setCurrentLocation] = useState(null);
    const [initialRegion, setInitialRegion] = useState(null);


    console.log(currentLocation);
    console.log(initialRegion);

    const endSamePoint = () => {
      setEndPoint(startingPoint);
    }

    
    //function to send starting point and distance to backend and get routes coordinates
    const findRoute = async (startingPoint,endPoint,distance) => {
        // Make a POST request to the API endpoint
        const startLatitude = startingPoint.latitude;
        const startLongitude = startingPoint.longitude;
        const endLatitude = endPoint.latitude;
        const endLongitude = endPoint.longitude;

        await axios.post(`${ROUTE}?startLatitude=${startLatitude}&startLongitude=${startLongitude}&endLatitude=${endLatitude}&endLongitude=${endLongitude}&distance=${distance}&user_id=wrx123`,
        {}, //empty body
        { headers: { Authorization: `Bearer ${userToken}` } }
        )
        .then((res) => {
          //console.log(res.data);
          const resData = res.data;
          const firstHalf = resData.suggested_route.startMid.routes[0].polyline.encodedPolyline;
          const secondHalf = resData.suggested_route.midEnd.routes[0].polyline.encodedPolyline;

          //to display the routes on the map by setting marker and polyline
          const decodePolyline = require('decode-google-map-polyline');
          const fistHalfDecoded = decodePolyline(firstHalf);
          const secondHalfDecoded = decodePolyline(secondHalf);
          
          const combinedPath = fistHalfDecoded.concat(secondHalfDecoded);
          //console.log(combinedPath);
          
          const decodedRoutes = combinedPath.map(item => {
              return { latitude: item.lat, longitude: item.lng };
          });
          setDecodedRoutes(decodedRoutes);
          console.log(decodedRoutes);
        
        })
        .catch((error)=>{
            console.log(error)
        })
 
    }
    
    const clearRoute = () => {
      setDecodedRoutes([{"latitude": 1.3485971625954045, "longitude": 103.68233638828144}]);
    }

    //function for user to confirm and navigate to startRun screen
    useEffect(() => {
    const getLocation = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        console.log("Permission to access location was denied");
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setCurrentLocation(location.coords);

      setInitialRegion({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      });
    };

    getLocation();
  }, []);


    return (
      <View style={styles.container}>
        <MapView style={styles.map} initialRegion={locationNTU} 
            //when users click on the map, it will log the coordinates
            onPress={ (event) => console.log(event.nativeEvent.coordinate) }> 
        
        {currentLocation && (
            
              <Marker
                coordinate={{
                  latitude: currentLocation.latitude,
                  longitude: currentLocation.longitude,
                }}
                title="Your Location"
              >
                <Image
                  source={require('../../assets/welcome/RunAnyWhereLogo.png')}
                  style={{ width: 50, height: 50 }}
                />
              </Marker>
         
            
          )}

        <Marker draggable
          coordinate = {startingPoint}
          pinColor = {"blue"} // any color
          title={"Starting Point"}
          onDragEnd={(event) => setStartingPoint(event.nativeEvent.coordinate)}/>


        <Marker draggable
          coordinate = {endPoint}
          pinColor = {"red"} // any color
          title={"End Point"}
          onDragEnd={(event) => setEndPoint(event.nativeEvent.coordinate)}/>

        <Polyline
            coordinates={decodedRoutes}
            strokeColor="#000" // fallback for when `strokeColors` is not supported by the map-provider
            strokeColors={[
              '#9360e3',
            ]}
            strokeWidth={3}
            />

          </MapView>

        <View style={styles.searchBox}>
          <TextInput 
              placeholder='Distance(km)' 
              style={styles.searchBoxLabel}
              onChangeText={(text) => setDistance(text)}
          />
          
          <View
              style={{ borderBottomColor: 'black', borderBottomWidth: StyleSheet.hairlineWidth,}}
          />
          
          <Button
            onPress={endSamePoint}
            title="Stop at the same location"
            color="#9360e3"
          />
          
          <Pressable style={styles.clearButton} onPress={clearRoute}>
            <Text style={styles.clearText}>Clear</Text>
          </Pressable>

          <TouchableOpacity style={styles.searchButton} onPress={()=>findRoute(startingPoint,endPoint,distance)} >
              <Text style={styles.searchButtonText}>Find Route(s)</Text>
          </TouchableOpacity>
        </View>  

        <TimerApp />

      </View>
    );
}

const styles = StyleSheet.create({
  container:{
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
  },
  searchBox:{
      position: 'absolute',
      backgroundColor: '#fff',
      top: 60,
      width: '90%',
      padding: 8,
      borderRadius: 20,
      borderWidth: 0.2, 
      marginTop: 10,
      borderColor: 'grey',
      shadowColor: 'black',
      shadowOffset: { width: 1, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 1.84,
  },
  clearButton:{
      backgroundColor: 'white',
      position: 'absolute',
      left:303,
      top:94,
  },
  clearText:{
      color:"#9360e3",
      fontSize: 15,
      fontWeight: 'bold', 
      padding: 5,
  },
  title:{
      fontSize: 17,
      color: 'black',
      fontWeight: 'bold', 
      padding: 5,
      marginLeft: 10, // Move the search box label towards the left
      textAlign: 'left', // Center horizontally
      textAlignVertical: 'center', // Center vertically
  },
  searchBoxLabel:{
      fontSize: 17,
      color: 'black',
      fontWeight: 'bold', 
      padding: 5,
      marginLeft: 10, // Move the search box label towards the left
      textAlign: 'left', // Center horizontally
      textAlignVertical: 'center', // Center vertically
  },
  searchButton:{
      backgroundColor: '#9360e3',
      padding: 10,
      borderRadius: 10,
      marginTop: 10,
      width: '50%',
      alignSelf: 'center',
      alignItems: 'center', // Center the content horizontally
      justifyContent: 'center', // Center the content vertically
  },
  searchButtonText:{
      color: 'white',
      fontSize: 18,
      fontWeight: 'bold', 
  },
  map: {
      flex: 1, 
      width: '100%',
      height: '100%',
  }
});