import React, { useContext } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image, SafeAreaView } from "react-native";
import { AuthContext } from "../../context/AuthContext";
import FeatherIcon from 'react-native-vector-icons/Feather';
import RunAnyWhereLogo from '../../assets/welcome/RunAnyWhereLogo.png';
import { Feather } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';

const ProfileScreen = ({navigation}) => {
    const { userInfo, userToken, logout } = useContext(AuthContext);

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.profile}>
                <View style={styles.profileAvatarWrapper}>
                    <Image source={RunAnyWhereLogo} style={styles.profilePicture} />
                    <View style={styles.profileAction}>
                        <FeatherIcon
                            color="#fff"
                            name="edit-3"
                            size={15}
                        />
                    </View>
                </View>

                <Text style={styles.profileName}>{userInfo.username}</Text>
                <Text style={styles.profileLocation}>Singapore</Text>
            </View>

            <View style={styles.buttonContainer}>
                <View style={styles.buttonGroup}>
                    <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Edit')}>
                        <View style={styles.buttonContent}>
                            <Feather name="edit" size={24} style={styles.icon} />
                            <Text style={styles.buttonText}>Edit / Update Profile</Text>
                            <View style={styles.rowSpacer} />
                            <FeatherIcon color="#C6C6C6" name="chevron-right" size={20} style={{marginRight: 10}} />
                        </View>
                    </TouchableOpacity> 
                    
                    <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Change')}>
                        <View style={styles.buttonContent}>
                            <Feather name="lock" size={24} style={styles.icon} />
                            <Text style={styles.buttonText}>Change Password</Text>
                            <View style={styles.rowSpacer} />
                            <FeatherIcon color="#C6C6C6" name="chevron-right" size={20} style={{marginRight: 10}} />
                        </View>
                    </TouchableOpacity>
                    
                    <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Emergency')}>
                        <View style={styles.buttonContent}>
                            <Feather name="phone" size={24} style={styles.icon} />
                            <Text style={styles.buttonText}>Emergency Contact</Text>
                            <View style={styles.rowSpacer} />
                            <FeatherIcon color="#C6C6C6" name="chevron-right" size={20} style={{marginRight: 10}} />
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Terms')}>
                        <View style={styles.buttonContent}>
                            <MaterialIcons name="description" size={24} style={styles.icon} />
                            <Text style={styles.buttonText}>Terms and Privacy Policies</Text>
                            <View style={styles.rowSpacer} />
                            <FeatherIcon color="#C6C6C6" name="chevron-right" size={20} style={{marginRight: 10}} />
                        </View>
                    </TouchableOpacity>
 
                    <TouchableOpacity style={styles.button} onPress={() => { logout() }}>
                        <View style={styles.buttonContent}>
                            <Feather name="log-out" size={24} style={styles.icon} />
                            <Text style={styles.buttonText}>Logout</Text>
                            <View style={styles.rowSpacer} />
                            <FeatherIcon color="#C6C6C6" name="chevron-right" size={20} style={{marginRight: 10}} />
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        marginTop: 70,
        padding: 30,
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: 0,
    },
    profile: {
        padding: 15,
        backgroundColor: 'white',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 20,
        marginBottom: 5,
        marginTop: 0,
        borderWidth: 2, 
        borderColor: 'white', 
        margin: 10,
    },
    
    profileAvatarWrapper: {
        position: 'relative',
    },
    profilePicture: {
        width: 140,
        height: 140,
        borderRadius: 20,
        borderWidth: 1, // Set the width of the border
        borderColor: '#e6e6fa', // Set the color of the border
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    profileAction: {
        position: 'absolute',
        right: -5,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center',
        width: 28,
        height: 28,
        borderRadius: 20,
        backgroundColor: '#007bff',
    },
    profileName: {
        marginTop: 20,
        fontSize: 19,
        fontWeight: '600',
        color: '#414d63',
        textAlign: 'center',
    },
    profileLocation: {
        marginTop: 0,
        fontSize: 14,
        color: '#989898',
        textAlign: 'center',
    },
    buttonContainer: {
        margin: 10,
        // backgroundColor: 'white',
        borderRadius: 20,
    },
    button: {
        backgroundColor: '#9360E3',
        margin: 15,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        shadowColor: 'black',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2.84,
        elevation: 10,
        marginBottom: 0,
    },
    buttonText: {
        fontSize: 15,
        fontWeight: '800',
        textAlign: 'left', 
        color: 'white',
        fontFamily: 'Arial',
    },
    buttonContent: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start', 
    },
    icon: {
        marginLeft: 20,
        marginRight: 12,
        padding: 10,
        color: 'white',
    },
    rowSpacer: {
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: 0,
    },
});

export default ProfileScreen;
