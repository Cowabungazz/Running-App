import { View, Text } from "react-native"

const PlansScreen = () =>{
    return (
        <View>
            <Text>Plans</Text>
        </View>
    )
}

export default PlansScreen