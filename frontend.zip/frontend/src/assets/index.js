export const google = require('./login-icons/google.png');
export const apple = require('./login-icons/apple.png');
export const sso = require('./login-icons/sso.png');

export const frame = require('./welcome/frame.png')
export const welcome = require('./welcome/welcome.png')

export const avatar_boy = require('./dashboard/avatar-boy.png');
export const cloudy = require('./dashboard/cloudy.png');
export const light_rain = require('./dashboard/light-rain.png');
export const night = require('./dashboard/night.png');
export const rainy = require('./dashboard/rainy.png');
export const sunny = require('./dashboard/sunny.png');
export const thunder = require('./dashboard/thunder.png');